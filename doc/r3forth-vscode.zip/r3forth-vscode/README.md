# r3forth — Syntax Highlighting

---

## English

Syntax highlighting extension for the [r3forth](https://github.com/phreda4/r3) language.

### Installation

Package and install from the extension source directory:

```
npx @vscode/vsce package --no-dependencies
code --install-extension r3forth-1.0.2.vsix
```

Files with the `.r3` extension are detected automatically.

### Color scheme

Colors are configured in VS Code's `settings.json` under `editor.tokenColorCustomizations`.

| Token | Scope | Color |
|---|---|---|
| User-defined words | `variable.language.word.r3forth` | `#00c000` |
| `:word` definition | `entity.name.function.definition.r3forth` | `#40f0f0` |
| `;` end word | `keyword.control.end.r3forth` | `#40f0f0` |
| `#var` data word | `constant.other.hash.r3forth` | `#ff00ff` |
| `'word` address-of | `variable.other.tick.r3forth` | `#00c000` |
| `^file` include | `entity.name.tag.caret.r3forth` | `#e0e080` |
| Number literals | `constant.numeric.*.r3forth` | `#e0e000` |
| Strings `"..."` | `string.quoted.double.r3forth` | `#d0d0d0` |
| Comments `\| ...` | `comment.line.r3forth` | `#555555` italic |
| `( )` code blocks | `punctuation.section.block.r3forth` | `#ff0000` |
| `[ ]` lambda | `punctuation.section.lambda.r3forth` | `#00c000` |
| Primitives | `keyword.other.primitive.r3forth` | `#00c000` |
| Fixed-point math | `keyword.other.fixedpoint.r3forth` | `#00c000` |
| Conditionals `>?` | `keyword.operator.predicate.r3forth` | `#00c000` |

### Prefixes

| Prefix | Meaning | Example |
|---|---|---|
| `\|` | Line comment | `\| this is ignored` |
| `:` | Define word | `:myword ... ;` |
| `::` | Define exported word | `::myword ... ;` |
| `#` | Define data word | `#var 0` |
| `##` | Define exported data word | `##var 0` |
| `'` | Address of word | `'myword` |
| `^` | Include file | `^r3/lib/math.r3` |
| `$` | Hexadecimal literal | `$FF` |
| `%` | Binary literal | `%1010` |
| `"` | String literal | `"hello"` |

### Recognized words

**Conditionals** — `0?` `1?` `+?` `-?` `=?` `<>?` `>?` `<?` `>=?` `<=?` `AND?` `NAND?` `IN?`

**Stack** — `dup` `drop` `swap` `over` `rot` `-rot` `nip` `pick2` `pick3` `pick4` `2dup` `2drop` `3drop` `4drop` `2over` `2swap`

**Arithmetic** — `+` `-` `*` `/` `mod` `/mod` `neg` `abs` `sqrt` `clz` `*/` `*>>` `<</` `<<` `>>` `>>>`

**Logic** — `and` `or` `xor` `nand` `not`

**Memory** — `@` `@+` `!` `!+` `+!` `c@` `c!` `w@` `w!` `d@` `d!` (and `+` variants)

**Registers** — `>a` `a>` `a+` `a@` `a!` `a@+` `a!+` (and B, CA, DA, CB, DB variants) `AB[` `]BA`

**Bulk memory** — `move` `move>` `fill` `cmove` `cmove>` `cfill` `dmove` `dmove>` `dfill`

**Return stack** — `>r` `r>` `r@`

**Fixed-point math** — `*.` `/.` `2/.` `int.` `fix.` `ceil` `sign` `sin` `cos` `tan` `sincos` `atan2` `sqrt.` `ln.` `exp.` `pow.` `log2.` `pow2.` `gamma.` `beta.` `tanh.` and more

**System** — `mem` `loadlib` `getproc` `sys0`–`sys10` `here` `mark` `empty` `ex`

### Extension structure

```
r3forth-vscode/
├── package.json                      # Extension manifest
├── language-configuration.json       # Bracket and comment config
├── syntaxes/
│   └── r3forth.tmLanguage.json       # TextMate grammar
└── themes/
    ├── r3forth-dark-color-theme.json
    └── r3forth-light-color-theme.json
```

---

## Español

Extensión de coloreo de sintaxis para el lenguaje [r3forth](https://github.com/phreda4/r3).

### Instalación

Empaquetar e instalar desde el directorio fuente de la extensión:

```
npx @vscode/vsce package --no-dependencies
code --install-extension r3forth-1.0.2.vsix
```

Los archivos `.r3` se detectan automáticamente.

### Esquema de colores

Los colores se configuran en `settings.json` bajo `editor.tokenColorCustomizations`.

| Token | Scope | Color |
|---|---|---|
| Palabras de usuario | `variable.language.word.r3forth` | `#00c000` |
| `:palabra` definición | `entity.name.function.definition.r3forth` | `#40f0f0` |
| `;` fin de palabra | `keyword.control.end.r3forth` | `#40f0f0` |
| `#var` dato | `constant.other.hash.r3forth` | `#ff00ff` |
| `'palabra` dirección | `variable.other.tick.r3forth` | `#00c000` |
| `^archivo` incluir | `entity.name.tag.caret.r3forth` | `#e0e080` |
| Números | `constant.numeric.*.r3forth` | `#e0e000` |
| Cadenas `"..."` | `string.quoted.double.r3forth` | `#d0d0d0` |
| Comentarios `\| ...` | `comment.line.r3forth` | `#555555` italic |
| `( )` bloques de código | `punctuation.section.block.r3forth` | `#ff0000` |
| `[ ]` lambda | `punctuation.section.lambda.r3forth` | `#00c000` |
| Primitivas | `keyword.other.primitive.r3forth` | `#00c000` |
| Matemática punto fijo | `keyword.other.fixedpoint.r3forth` | `#00c000` |
| Condicionales `>?` | `keyword.operator.predicate.r3forth` | `#00c000` |

### Prefijos

| Prefijo | Significado | Ejemplo |
|---|---|---|
| `\|` | Comentario de línea | `\| esto se ignora` |
| `:` | Definir palabra | `:mipalabra ... ;` |
| `::` | Palabra exportada | `::mipalabra ... ;` |
| `#` | Palabra de datos | `#var 0` |
| `##` | Dato exportado | `##var 0` |
| `'` | Dirección de palabra | `'mipalabra` |
| `^` | Incluir archivo | `^r3/lib/math.r3` |
| `$` | Literal hexadecimal | `$FF` |
| `%` | Literal binario | `%1010` |
| `"` | Cadena de texto | `"hola"` |

### Palabras reconocidas

**Condicionales** — `0?` `1?` `+?` `-?` `=?` `<>?` `>?` `<?` `>=?` `<=?` `AND?` `NAND?` `IN?`

**Pila** — `dup` `drop` `swap` `over` `rot` `-rot` `nip` `pick2` `pick3` `pick4` `2dup` `2drop` `3drop` `4drop` `2over` `2swap`

**Aritmética** — `+` `-` `*` `/` `mod` `/mod` `neg` `abs` `sqrt` `clz` `*/` `*>>` `<</` `<<` `>>` `>>>`

**Lógica** — `and` `or` `xor` `nand` `not`

**Memoria** — `@` `@+` `!` `!+` `+!` `c@` `c!` `w@` `w!` `d@` `d!` (y variantes `+`)

**Registros** — `>a` `a>` `a+` `a@` `a!` `a@+` `a!+` (y variantes B, CA, DA, CB, DB) `AB[` `]BA`

**Memoria en bloque** — `move` `move>` `fill` `cmove` `cmove>` `cfill` `dmove` `dmove>` `dfill`

**Pila de retorno** — `>r` `r>` `r@`

**Matemática punto fijo** — `*.` `/.` `2/.` `int.` `fix.` `ceil` `sign` `sin` `cos` `tan` `sincos` `atan2` `sqrt.` `ln.` `exp.` `pow.` `log2.` `pow2.` `gamma.` `beta.` `tanh.` y más

**Sistema** — `mem` `loadlib` `getproc` `sys0`–`sys10` `here` `mark` `empty` `ex`

### Estructura de la extensión

```
r3forth-vscode/
├── package.json                      # Manifiesto de la extensión
├── language-configuration.json       # Configuración de brackets y comentarios
├── syntaxes/
│   └── r3forth.tmLanguage.json       # Gramática TextMate
└── themes/
    ├── r3forth-dark-color-theme.json
    └── r3forth-light-color-theme.json
```
